




//Temporary
void Init_Heap()	{
	
}
//Temporary
void Alloc_Mem()	{
	
}
//Temporary
void Free_Mem()	{
	
}
//Temporary
void IsEmpty()	{
	
}

void ShowFree()	{
	
}
void ShowAlloc()	{
	
}
