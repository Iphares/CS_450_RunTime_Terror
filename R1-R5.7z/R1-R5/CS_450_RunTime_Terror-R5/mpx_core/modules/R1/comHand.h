/// @file

int comHand();
