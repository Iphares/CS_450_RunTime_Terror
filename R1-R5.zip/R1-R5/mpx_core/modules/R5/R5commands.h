//Temporary
void Init_Heap(u32int size);

//Temporary
void Alloc_Mem(u32int size);

//Temporary
void Free_Mem(u32int address);

//Temporary
void IsEmpty();

void ShowFree();
void ShowAlloc();
